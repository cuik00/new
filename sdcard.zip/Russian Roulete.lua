--Rusian Roulete--
--Created by Layscape--
--SC Tinggal Tancap GAS
--Hasil Maksimal Gunakan RDP Server Khusus Betting
local clock = os.clock

function sleep(n)
    local t0 = clock()
    while clock() - t0 <= n do end
end
chance          = 85
roulete         = {11,22,33,44,55}
basebet         = balance / 10000000
nextbet         = basebet
a               = 0
tmpprofit       = 0
currprofit      = 0
calm            = basebet * (10 ^ 3)
calmmodrandom   = 0--(0/1)On/Off Mode Kalem--Yang On salah satu aja
calmmodroulete  = 0--(0/1)On/Off Mode Kalem--
lys             = 0
autowd          = 0--(0/1)On/Off autowd
wallet          = "x"
jumlahwd        = 10
wdsetelahprofit = 30
function dobet()
    print("Currprofit"..currprofit.." Tempprofit"..tmpprofit)
    if (nextbet > calm and calmmodrandom == 1) then
        print("Slow Down, Cape")
        sleep(1)--Atur Time Sleep/Delay--
        resetseed()
        lys     = 1
        nextbet = nextbet + (nextbet/4)
        a       = math.random(0,3)
    end
    if (nextbet > calm and calmmodroulete == 1) then
        print("Slow Down, Cape")
        sleep(1)--Atur Time Sleep/Delay--
        resetseed()
        lys     = 1
        a       = 1
        nextbet = nextbet + (nextbet/4)
    end
    
    if (a > 4 and lys == 0) then
        a       = 1
        nextbet = nextbet + (nextbet/4)
    else
       a += 1
    end
    chance = roulete[a]
    if (win)then
        tmpprofit += currentprofit
    else
        tmpprofit += currentprofit
    end
    if (tmpprofit > currprofit)then
        nextbet    = basebet
        currprofit = tmpprofit
        lys        = 0
    end
    if(autowd == 1 and currprofit > wdsetelahprofit)then
        withdraw(jumlahwd,wallet)
        currprofit = 0
        tmpprofit  = 0
    end
end