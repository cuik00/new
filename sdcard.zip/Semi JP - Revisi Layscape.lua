-- LUA Script Semi-JP 1.0--
--Creator @Layscape, @Mbel--
-- Sugested Balance 1K level 5--
levelthreshold = 6--level Risk to Safe 4-10--
-- level 6 up to 70% profit/day--
-- Not Support 999Dice (Slowly) --
secure        = 1--Risk to Safe 0-3 --
basebet       = balance/(10^levelthreshold)/(10^secure) --Don't Change This--
multijackpot  = 2--Safe to Risk 1-3 --
pb1           = basebet*8
pb2           = basebet*(10^levelthreshold)
chance        = math.random(60,78)
nextbet       = basebet
targetpercent = 100 --set your target profit as percent--
target        = balance + (balance * targetpercent /100)
loss          = 0
won           = 0
countwin      = 0
shock         = 0
stat          = 0
function dobet()
    if (win and chance < 15) then
        countwin+=1
    
    end
    
    if (countwin >= 3) then
        bethigh  = true
        countwin = 0
        chance   = math.random(55,68)
        nextbet  = basebet
        shock    = 0
    end
    if (win) then 
        loss = 0
        won +=1
         print("Shock = "..shock)
       print("CW = "..countwin)
       print(string.format("%.8f", pb1))
       print("Stat = "..stat)
    else 
        loss+=1
        won = 0 
       print("Shock = "..shock)
       print("CW = "..countwin)
       print(string.format("%.8f", pb1))
       print("Stat = "..stat)
    end
   if (loss>=1 and nextbet < pb1)then
        chance = math.random(5,35)
    end
    if (loss==3) then
        bethigh = false
        nextbet = previousbet*2
        
    end
    if (nextbet == pb1) then
        nextbet  = basebet
        countwin = 0
        shock    += multijackpot
        stat = 1
        resetseed()
        
     end
    if (nextbet > pb1 and stat == 0) then
        stop()
        print("Due Math Error We Stop Betting. Start Again")
    end
    if (shock == 0) then
        stat = 0
    end
    
    if (shock >= 1) then
        chance   = math.random(5.5*100,22.7*100)/100
        nextbet  = previousbet * 1.235
        countwin = 1
        if (win) then
            nextbet = basebet
            shock   -= 1 
            
        else
            chance  = math.random(5,9)
            nextbet = previousbet * 1.12
        if (nextbet > pb2) then
            nextbet = basebet
        end
        end
    end
     if (nextbet > 0.001) then
         sleep(0.2)
     end
     
if balance>target then 
       stop()
end
end