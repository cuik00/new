chance      = 90
if_win      = 1
if_lose     = 5.05
base        = 0.001
chanceAwal  = 85.88
chanceAkhir = 93.33
if_profit   = 0.000001
wincount    = 0
profit1     = 0
nextbet     = base


resetstats()
function dobet()

    chance = math.random(chanceAwal*100.0, chanceAkhir*100.0)/100.0

    if win then
        
        wincount+=1
        
        if (profit > (profit1 + if_profit)) then
            
            wincount = 0
            
            profit1 = profit
            
            nextbet  = base
            
        else
            
            nextbet = previousbet*if_win
            
        end
        
    else
        
        wincount = 0
        
        nextbet  = previousbet*if_lose
        
    end

end