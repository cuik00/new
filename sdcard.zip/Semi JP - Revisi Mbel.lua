-- LUA Script Semi-JP 1.0--
--Creator @Layscape, @Mbel--

thresholdsecured  = 7--level risk to safe 4-10--

-- Sugested Balance 1K level 7--
levelthreshold = 6-- level 6 up to 70% profit/day--
-- Not Support 999Dice (Slowly) --
basebet       = balance /(10^thresholdsecured)--Don't Change This--
prebet        = basebet/4
multijackpot  = 2 --safe to risk 1-3--
pb1           = basebet*8
pb2           = basebet*(10^levelthreshold)
chance        = math.random(55,68)
nextbet       = basebet
targetpercent = 10 --set your target profit as percent--
target        = balance + (balance * targetpercent /100)
loss          = 0
won           = 0
countwin      = 0
shock         = 0
roundprofit   = 0
initbalance   = balance
function dobet()
   roundprofit += currentprofit
   initbalance = balance+roundprofit
  if (win) then
      if roundprofit > basebet*100 then
            initbalance = balance+roundprofit
            nextbet     = prebet
            roundprofit = 0 
            loss        = 0
            won         = 0
            countwin    = 0
            shock       = 0
        end
    end
    if (countwin == 10) then
        bethigh  = true
        countwin = 0
        chance   = math.random(85,88)
        nextbet  = basebet
        shock    = 0
    end
    if (win) then 
        loss = 0
        won +=1
    else 
        loss+=1
        won = 0  
    end
    if (loss>=1)then
        chance = math.random(6*100,10*100)/100
    end
    if (loss==11) then
        bethigh = false
        nextbet = previousbet*2
        
    end
    if (nextbet >= pb1) then
        nextbet = prebet
        shock    += multijackpot
        resetseed()
        print(shock)
     end
    if (shock > 1) then
        chance  = math.random(22.5*100,25.7*100)/100
        nextbet = previousbet * 2
        shock+=1
        if (win) then
            nextbet = previousbet*0.75
            shock -= 1
            countwin+=1
        else
            chance  = math.random(11*100,22*100)/100
            nextbet = previousbet * 1.123
        if (nextbet > pb2) then
            shock   = 1
            nextbet = previousbet*0.01
        end
      end
    end
end
if (nextbet > basebet*1000) then
         sleep(2)
     end
     
if balance>target then 
       stop()
end
end