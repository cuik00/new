-- LUA Script Semi-JP 1.0--
--Creator  @Mbel--@Layscape
-- Sugested Balance over 1K level 5--
levelthreshold = 5--level risk to safe 3-10--more high more safe
basebet        = balance/(10^levelthreshold)--Don't Change This--
prebet         = basebet/2
multijackpot   = 2 --safe to risk 1-3--more small more fun
pb1            = basebet+(basebet/2)
pb2            = basebet*50
chance         = math.random(55,68)
nextbet        = basebet
targetpercent  = 10 --set your target profit as percent--
target         = balance *10000.2 --set your target profit as percent--
loss           = 0
won            = 0
ch             = 0
countwin       = 0
shock          = 0
roundprofit    = 0
initbalance    = balance
function dobet()
    bethigh = !bethigh
   roundprofit += currentprofit
   initbalance = balance+roundprofit
   if roundprofit > 0 then
       chance = math.random(8,60)
            nextbet     = prebet
            roundprofit = 0 
            ch          = 0
            loss        = 0
            won         = 0
            countwin    = 0
            shock       = 0
        end
    if (win) then
        loss   = 0
        won +=1
    else 
        --   ch+=1
        loss+=1
        won = 0  
    end
    -- if (ch==2) then
    --    ch     = 0
        --    chance = 90
        --  end
    --  if(ch == 1 ) then
    --       ch = 1
    --   chance = 10
      -- end
   if (loss>=1)then
      chance = math.random(6,66)
    end --
  if (loss==5) then
        nextbet = previousbet+(basebet/10)
 
    end
    if (nextbet >= pb1) then
        nextbet = prebet
        shock    += multijackpot
        print(shock)
     end
    if (shock > 1) then
        chance  = 20
        nextbet = previousbet * 2
        shock+=1
        if (win) then
            nextbet = previousbet*0.85
            shock -= 1
            countwin+=1
        else
            chance  = math.random(6,37)
            nextbet = previousbet * 1.2345
       
        end
        if nextbet> pb2 then
            chance  = math.random(11,44)
            nextbet = previousbet*1.12345
        end
    end
     
if balance>target then 
       stop()
end
end