-- LUA Script Semi-JP 1.0--
--Creator @Layscape, @Mbel--
-- Sugested Balance 1K level 7--
levelthreshold = 6 --level safe to risk 4-10--
-- level 6 up to 70% profit/day--

basebet        = 0.00001 --Carefull change this--
multijackpot   = 2 --safe to risk 1-3--
pb1            = basebet*8
pb2            = basebet*(10^levelthreshold)
chance         = math.random(55,68)
nextbet        = basebet
targetpercent  = 100 --set your target profit as percent--
target         = balance + (balance * targetpercent /100)
loss           = 0
won            = 0
countwin       = 0
shock          = 0

function dobet()
    if (win and chance < 15) then
        countwin+=1
    
    end
    
    if (countwin == 4) then
        bethigh  = true
        countwin = 0
        chance   = math.random(55,68)
        nextbet  = basebet
        shock    = 0
    end
    if (win) then 
        loss = 0
        won +=1
    else 
        loss+=1
        won = 0  
    end
    if (loss>=1)then
        chance = math.random(5,35)
    end
    if (loss==3) then
        bethigh = false
        nextbet = previousbet*2
        
    end
    if (nextbet == pb1) then
        nextbet  = basebet
        countwin = 0
        shock    += multijackpot
        resetseed()
        print(shock)
     end
    if (shock > 1) then
        chance   = math.random(5.5*100,22.7*100)/100
        nextbet  = previousbet * 1.35
        countwin = 1
        if (win) then
            nextbet = basebet
            shock -= 1
        else
            chance  = math.random(7,15)
            nextbet = previousbet * 1.2
        if (nextbet > pb2) then
            nextbet = basebet
        end
        end
    end
        
if balance>target then 
       stop()
end
end