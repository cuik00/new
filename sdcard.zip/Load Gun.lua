-- Warning -- by wedus g@mbel
--Hasil Maksimal Gunakan RDP Server Khusus Betting
-- Modalmu harus diatas 0.01 all coin gan
-- Makin gede modalmu makin cepat amblas/dibegal
-- Semakin banyak loss semakin cepat duit raib di rek
-- kalau Loss  segera off bot main lagi nanti aja, klo ingat (jgn judi mulu diingat, shalat jg diingat jg)ðŸ˜ŽðŸ˜ŽðŸ˜Ž
-- Sehari main 3 kali aja, seperti petunjuk dokter psikologi
-- Jangan Sayangi duit mu, profit dikit buat apaan???. Lebih baik main barbar
-- Ini adalah Permainan Bisa Menang Bisa Kalah !!! Klo kalah jgn nangis dipojokkan dan klo menang jgn diem2 bae
-- kalo donasi disini aja gan
-- DPofpvSqrAFuEyRDJycrVXkQJ6RfLVbY2M
-- UBAH bet SESUAI ATURAN KALIAN, JANGAN COBA PILIH BALANCE/1000
--======================================--
basebet     = balance/10000000 -- standart 10000000 more big more safe
chance      = 69
min         = 11
max         = 22
mult        = 1.252 --set multiplier
win1        = 0
win2        = 0
loss1       = 0
loss2       = 0
nextbet     = basebet
boom1       = false
loadgun     = basebet
boom2       = true
roundprofit = 0
target      = balance*1.1 -- set your target profit
bs1         = 1
bs2         = 3-- set step on your losscount
function dobet()
    roundprofit+=currentprofit
    bethigh = !bethigh
    if balance>target then 
        stop()
    end 
    if basebet< 0.00000002 then
        basebet=0.00000002
      end
chance = math.random(min*100,max*100)/100
if roundprofit>basebet then
   roundprofit = 0
   win1        = 0
   win2        = 0
   loss1       = 0
   loss2       = 0
   nextbet     = basebet
   boom1       = false
   loadgun     = basebet
   boom2       = true
end
    if win then
        loss1 = 0
        if (boom1) then
            loss2 = 0
            if boom1 then
                loadgun = loadgun
                boom1   = false
                boom2   = true
                resetseed()
            end
        end
        win1 = win1 + 1
        win2 = win2 + 1
        if win2 == 999 then
            -- resetseed()
            win2 = 0
        end
        nextbet = loadgun/2
    else
        if boom1 then boom1 = false end
        loss1    = loss1 + 1
        if loss1 == bs1 then
            loss2 = loss2 + 1
            if boom2 then
                loadgun = basebet * 1.3
                boom2   = false
            else
                loadgun = loadgun *mult
            end
        end
        if loss1 == bs1 then
            nextbet = loadgun
            betto   = true
            loss1   = 1
        end
        if loss1 == bs2 then
            nextbet = loadgun
            betto   = true
            loss1   = 0
        end
        if win then
            nextbet = basebet
            chance  = math.random(min*100,max*100)/100
        end
    end
end